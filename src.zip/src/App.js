import RouterApp from './rotas.js'
function App() {
  return (
    <div>
      <RouterApp/>
    </div>
  );
}

export default App;